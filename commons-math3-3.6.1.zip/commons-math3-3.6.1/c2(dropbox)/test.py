import Tkinter
import os
import sys


def sap2():
	name1=raw_input("Enter the name of directory which you want delete: ")
	print "Deleting directory...."
	os.system("./dropbox_uploader.sh delete "+name1+"")
	print "Directory Deleted"

def sap3():
	name=raw_input("Enter name of directory which you want to make: ")
	print "Creating directory....."
	os.system("./dropbox_uploader.sh mkdir "+name+"")
	print "Directory Created!!!"

def sap4():
	print "Directories are: "
	os.system("./dropbox_uploader.sh list")
	print "Directories are listed above"

def sap5():
	print "File is uploading...."
	os.system("./dropbox_uploader.sh upload /home/atharva/a.txt /" )
	print "File Uploaded!!!"
	
def sap7():
	os.system("./dropbox_uploader.sh download /a.txt /home/atharva/cl3_try")
	os.system("cat /home/atharva/cl3_try/a.txt")

def sap6():
	exit(0)

class simpleapp(Tkinter.Tk):
      def __init__(self,parent):
        Tkinter.Tk.__init__(self,parent)
        self.parent = parent
        self.initialize()

      def initialize(self):
        self.grid()


	button = Tkinter.Button(self,text="Delete",command=sap2)
	button.grid(column=1,row=2)

	button = Tkinter.Button(self,text="Create Directory",command=sap3)
	button.grid(column=1,row=4)
	
	button = Tkinter.Button(self,text="List Directory",command=sap4)
	button.grid(column=1,row=6)

	button = Tkinter.Button(self,text="Upload",command=sap5)
	button.grid(column=1,row=8)
	
	button = Tkinter.Button(self,text="Exit",command=sap6)
	button.grid(column=1,row=10)

	button = Tkinter.Button(self,text="View",command=sap7)
	button.grid(column=1,row=12)


if __name__=="__main__":
	app = simpleapp(None)
	app.title("Cloud Commands")
	app.mainloop()
