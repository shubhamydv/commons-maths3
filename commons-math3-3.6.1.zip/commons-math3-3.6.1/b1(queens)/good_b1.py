import json 

cnt = []

def issafe(row , column):
    for r in range(8):
        for c in range(8):
            if(board[r][c] == 1):
                if(r == row or c == column or abs(r-row) == abs(c - column)):
                    return 0 
    return 1

def place(board , row  ):
    if(row == 8):
        cnt.append(0)
        printboard(board)
        return
    ##printboard(board)
    for column in range(8):
        
        if(issafe(row , column)):
            board[row][column] = 1
            place(board , row+1)
            board[row][column] = 0

        



def printboard(board):
    for i in range(8):
        for j in range(8):
            print board[i][j],
        print ""
    print ""


fh = open("input.json" , "r+")


value = json.loads(fh.read())


start_column = value["start"]

print "Starting position : \n",start_column
board = []

for  i in range(8):
    vv = [0]*8
    board.append(vv)

#place the first queen itself 
board[0][start_column-1] = 1

place(board , 1)


print "Total possible solutions : \n",len(cnt)

