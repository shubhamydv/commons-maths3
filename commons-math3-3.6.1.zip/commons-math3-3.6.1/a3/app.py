from flask import *
from booth import booth

app = Flask(__name__)

@app.route('/')
def home():
	return render_template('index.html', prod = None)

@app.route('/multiply', methods=['POST','GET'])
def booths():
	return render_template('index.html', prod = booth(int(request.form['num1']), int(request.form['num2'])))

if __name__ == '__main__':
	app.run()
