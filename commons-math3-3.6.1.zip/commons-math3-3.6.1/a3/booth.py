def booth(p1,p2):
	flag=0
	arr1=[]
	if(p1<0 and p2>0)or(p2<0 and p1>0):
		flag=1
	p1=abs(p1)
	p2=abs(p2)
	while p1!=0:
		arr1.append(p1%2)
		p1/=2
		p1=int(p1)
	ans=0
	arr1.append(0)
	qi=0
	for i in range(len(arr1)):
		if(arr1[i]==qi):
			pass
		elif(arr1[i]==1):
			ans-=p2
		else:
			ans+=p2
		p2=p2<<1
		qi=arr1[i]

	if flag:
		ans=-ans
	return ans		





































