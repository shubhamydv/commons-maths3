from flask import *

app=Flask(__name__)

@app.route('/')
def home():
	return render_template('index.html',msg="")

@app.route('/calculate',methods=['POST','GET'])
def calc():
	return render_template('index.html',msg=checker(request.form['expr']))

def checker(string):
	filedata=""
	with open('data.txt','rt') as f:
		for line in f:
			filedata+=line
	
	c=filedata.replace('.','')
	c=c.replace('\n','')	
	c2=c.replace(',','')
	c2=c2.lower()
	c3=c2.split(' ')
	print c3
	d=string.replace('.','')
	d2=d.replace(',','')
	d2=d2.lower()
	d3=d2.split(' ')
	print d3
	comm=list(set(c3)&set(d3))
	print comm
	count=len(comm)
	print count
	score=float(count)/(len(set(c3)))*100
	return str(score)

if __name__=='__main__':
	app.run()
